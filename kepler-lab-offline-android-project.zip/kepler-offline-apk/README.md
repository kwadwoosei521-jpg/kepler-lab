# Kepler Lab — Offline Android build

This is an offline-first Android wrapper for the supplied Kepler Lab simulator. The simulator code and its UI are bundled into the APK; it does not need a website or network connection to run. The included service worker also caches the web build when served over HTTPS.

## Build the APK (Windows/macOS/Linux)

Requirements: Node.js 20+, Android Studio with Android SDK installed, and a JDK supported by your Android Gradle Plugin (Android Studio supplies a compatible JDK).

1. Extract this folder.
2. Open a terminal in this folder and run `npm install`.
3. Run `npm run build`.
4. Run `npx cap add android` (only the first time).
5. Run `npx cap sync android`.
6. Run `npx cap open android`.
7. In Android Studio, wait for Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. The debug APK is normally at `android/app/build/outputs/apk/debug/app-debug.apk`.

For later changes, run `npm run build` then `npx cap sync android` before rebuilding.

## Offline notes

- The orbit calculations, controls, and rendering run locally.
- The Android app loads its bundled `dist` files from the APK, so its main simulator does not require internet.
- Any features added later that depend on remote APIs, remote images, or remote fonts will need local assets or an internet connection.
