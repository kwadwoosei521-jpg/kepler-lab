/** Keplerian relative orbit. Sun at the origin, periapsis on +x.
 *  Time: years. Distance: AU. Masses: solar masses.
 *  G = 4π² so that T = a^(3/2) / sqrt(M_sun + M_planet) years.
 */

export const TWO_PI = Math.PI * 2;
export const G = 4 * Math.PI * Math.PI;

export type OrbitState = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  speed: number;
  E: number;
  M: number;
};

export function totalMass(mSun: number, mPlanet: number): number {
  return Math.max(1e-4, mSun + mPlanet);
}

export function periodYears(a: number, mSun = 1, mPlanet = 0): number {
  return Math.pow(Math.max(a, 1e-6), 1.5) / Math.sqrt(totalMass(mSun, mPlanet));
}

export function solveEccentricAnomaly(M: number, e: number): number {
  const m = ((M % TWO_PI) + TWO_PI) % TWO_PI;
  let E = e < 0.8 ? m : Math.PI;
  for (let i = 0; i < 14; i++) {
    const f = E - e * Math.sin(E) - m;
    const fp = 1 - e * Math.cos(E);
    const step = f / fp;
    E -= step;
    if (Math.abs(step) < 1e-12) break;
  }
  return E;
}

export function orbitState(
  a: number,
  e: number,
  tYears: number,
  mSun = 1,
  mPlanet = 0,
): OrbitState {
  const n = TWO_PI / periodYears(a, mSun, mPlanet);
  const M = n * tYears;
  const E = solveEccentricAnomaly(M, e);
  const b = a * Math.sqrt(Math.max(0, 1 - e * e));
  const cosE = Math.cos(E);
  const sinE = Math.sin(E);
  const x = a * (cosE - e);
  const y = b * sinE;
  const dEdt = n / Math.max(1e-8, 1 - e * cosE);
  const vx = -a * sinE * dEdt;
  const vy = b * cosE * dEdt;
  const r = Math.hypot(x, y);
  return { x, y, vx, vy, r, speed: Math.hypot(vx, vy), E, M };
}

/** Areal velocity of the relative orbit (AU² / year). */
export function arealVelocity(a: number, e: number, mSun = 1, mPlanet = 0): number {
  const b = a * Math.sqrt(Math.max(0, 1 - e * e));
  return (Math.PI * a * b) / periodYears(a, mSun, mPlanet);
}

export type Preset = {
  id: string;
  name: string;
  a: number;
  e: number;
  note: string;
};

export const PRESETS: Preset[] = [
  { id: "mercury", name: "Mercury", a: 0.387, e: 0.206, note: "Fast, noticeably oval" },
  { id: "earth", name: "Earth", a: 1, e: 0.017, note: "Almost a circle" },
  { id: "mars", name: "Mars", a: 1.524, e: 0.093, note: "Kepler’s own planet" },
  { id: "halley", name: "Halley-like", a: 2.6, e: 0.82, note: "Comet: slow far, fast near" },
  { id: "circle", name: "Circle", a: 1.4, e: 0, note: "Zero eccentricity control" },
];
