import { useEffect, useRef, useState } from "react";
import { Pause, Play, RotateCcw, Ruler } from "lucide-react";
import {
  PRESETS,
  arealVelocity,
  orbitState,
  periodYears,
  type Preset,
} from "@/lib/kepler";

type Overlays = {
  foci: boolean;
  axes: boolean;
  velocity: boolean;
  trail: boolean;
  ghost: boolean;
  sectors: boolean;
};

const DEFAULT_OVERLAYS: Overlays = {
  foci: true,
  axes: true,
  velocity: true,
  trail: true,
  ghost: false,
  sectors: true,
};

function format(n: number, digits = 3): string {
  if (!Number.isFinite(n)) return "—";
  const abs = Math.abs(n);
  if (abs !== 0 && (abs < 0.01 || abs >= 1000)) return n.toExponential(2);
  return n.toFixed(digits);
}

export function KeplerLab() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [presetId, setPresetId] = useState("mars");
  const [a, setA] = useState(1.524);
  const [e, setE] = useState(0.093);
  const [speed, setSpeed] = useState(1);
  const [mSun, setMSun] = useState(1);
  const [mPlanet, setMPlanet] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [overlays, setOverlays] = useState<Overlays>(DEFAULT_OVERLAYS);
  const [windowYears, setWindowYears] = useState(0.2);
  const [readout, setReadout] = useState({
    r: 1.52,
    speedAu: 0,
    t: 0,
    measuredT: 0,
    area1: 0,
    area2: 0,
    theoryArea: 0,
  });

  const sim = useRef({
    t: 0,
    playing: true,
    a: 1.524,
    e: 0.093,
    speed: 1,
    mSun: 1,
    mPlanet: 0,
    overlays: DEFAULT_OVERLAYS,
    windowYears: 0.2,
    trail: [] as { x: number; y: number }[],
    lastPeri: 0,
    sawPeri: false,
    measuredT: 0,
    prevE: 0,
    sectorPhase: 0,
    sectorStart: 0,
    poly1: [] as { x: number; y: number }[],
    poly2: [] as { x: number; y: number }[],
    area1: 0,
    area2: 0,
    armed: true,
  });

  useEffect(() => {
    const s = sim.current;
    s.playing = playing;
    s.a = a;
    s.e = e;
    s.speed = speed;
    s.mSun = mSun;
    s.mPlanet = mPlanet;
    s.overlays = overlays;
    s.windowYears = windowYears;
  }, [playing, a, e, speed, overlays, windowYears, mSun, mPlanet]);

  function applyPreset(p: Preset) {
    setPresetId(p.id);
    setA(p.a);
    setE(p.e);
    resetOrbit(p.a, p.e);
  }

  function resetOrbit(nextA = a, nextE = e) {
    const s = sim.current;
    s.t = 0;
    s.trail = [];
    s.lastPeri = 0;
    s.sawPeri = false;
    s.measuredT = 0;
    s.prevE = 0;
    s.sectorPhase = 0;
    s.sectorStart = 0;
    s.poly1 = [];
    s.poly2 = [];
    s.area1 = 0;
    s.area2 = 0;
    s.armed = true;
    s.a = nextA;
    s.e = nextE;
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let last = performance.now();
    let accUi = 0;

    const resize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = parent.clientWidth;
      const h = parent.clientHeight;
      canvas.width = Math.max(1, Math.floor(w * dpr));
      canvas.height = Math.max(1, Math.floor(h * dpr));
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
    };
    resize();
    const ro = new ResizeObserver(resize);
    if (canvas.parentElement) ro.observe(canvas.parentElement);

    const polygonArea = (pts: { x: number; y: number }[]) => {
      if (pts.length < 3) return 0;
      let sum = 0;
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        const q = pts[(i + 1) % pts.length];
        sum += p.x * q.y - q.x * p.y;
      }
      return Math.abs(sum) / 2;
    };

    type Sim = typeof sim.current;
    const sample = (s: Sim, record: boolean) => {
      const st = orbitState(s.a, s.e, s.t, s.mSun, s.mPlanet);
      if (!record) return st;
      if (s.overlays.trail) {
        const lastPt = s.trail[s.trail.length - 1];
        if (!lastPt || Math.hypot(st.x - lastPt.x, st.y - lastPt.y) > s.a * 0.012) {
          s.trail.push({ x: st.x, y: st.y });
          if (s.trail.length > 900) s.trail.shift();
        }
      } else if (s.trail.length) {
        s.trail = [];
      }

      const wrapped = s.prevE > 5 && st.E < 1;
      if (wrapped && s.t > 0.02) {
        if (s.sawPeri) s.measuredT = s.t - s.lastPeri;
        s.lastPeri = s.t;
        s.sawPeri = true;
      }
      s.prevE = st.E;

      if (s.overlays.sectors) {
        const win = s.windowYears;
        if (s.armed) {
          s.armed = false;
          s.sectorPhase = 1;
          s.sectorStart = s.t;
          s.poly1 = [{ x: 0, y: 0 }, { x: st.x, y: st.y }];
          s.poly2 = [];
          s.area2 = 0;
        } else if (s.sectorPhase === 1) {
          s.poly1.push({ x: st.x, y: st.y });
          if (s.t - s.sectorStart >= win) {
            s.poly1.push({ x: 0, y: 0 });
            s.area1 = polygonArea(s.poly1);
            s.sectorPhase = 2;
            s.sectorStart = s.t;
            s.poly2 = [{ x: 0, y: 0 }, { x: st.x, y: st.y }];
          }
        } else if (s.sectorPhase === 2) {
          s.poly2.push({ x: st.x, y: st.y });
          if (s.t - s.sectorStart >= win) {
            s.poly2.push({ x: 0, y: 0 });
            s.area2 = polygonArea(s.poly2);
            s.sectorPhase = 0;
          }
        }
      }
      return st;
    };

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const s = sim.current;
      if (s.playing) {
        const target = s.t + dt * s.speed;
        const step = 0.004;
        while (s.t + step < target) {
          s.t += step;
          sample(s, true);
        }
        s.t = target;
        sample(s, true);
      }
      const st = orbitState(s.a, s.e, s.t, s.mSun, s.mPlanet);

      draw(ctx, canvas, s, st);

      accUi += dt;
      if (accUi > 0.12) {
        accUi = 0;
        const theory = arealVelocity(s.a, s.e, s.mSun, s.mPlanet) * s.windowYears;
        setReadout({
          r: st.r,
          speedAu: st.speed,
          t: s.t,
          measuredT: s.measuredT,
          area1: s.area1,
          area2: s.area2,
          theoryArea: theory,
        });
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, []);

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl flex-col gap-4 px-4 py-5 md:px-6">
      <header className="flex flex-col gap-1">
        <p className="text-xs font-medium tracking-[0.18em] text-accent uppercase">
          Orbital mechanics bench
        </p>
        <h1 className="font-serif text-3xl font-medium tracking-tight text-fg md:text-4xl">
          Kepler Lab
        </h1>
        <p className="max-w-2xl text-sm leading-relaxed text-muted">
          Change the ellipse, run the clock, and check the three laws against the numbers.
          Distances are astronomical units; time is years. The sun sits at one focus.
        </p>
      </header>

      <div className="grid flex-1 gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="flex min-h-[320px] flex-col gap-3">
          <div className="relative min-h-[340px] flex-1 overflow-hidden rounded-[var(--radius)] border border-border bg-bg">
            <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Stat label="Distance r" value={`${format(readout.r, 3)} AU`} />
            <Stat label="Speed" value={`${format(readout.speedAu, 2)} AU/yr`} />
            <Stat label="Clock" value={`${format(readout.t, 2)} yr`} />
            <Stat
              label="Measured period"
              value={readout.measuredT > 0 ? `${format(readout.measuredT, 3)} yr` : "waiting…"}
              hint={readout.measuredT > 0 ? `law ${format(periodYears(a, mSun, mPlanet), 3)}` : "one full lap"}
            />
          </div>
        </div>

        <aside className="flex flex-col gap-4 rounded-[var(--radius)] border border-border bg-surface p-4">
          <div>
            <p className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">Bodies</p>
            <div className="flex flex-wrap gap-2">
              {PRESETS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => applyPreset(p)}
                  className={
                    "min-h-11 rounded-full border px-3 text-sm " +
                    (presetId === p.id
                      ? "border-primary bg-primary text-bg"
                      : "border-border bg-surface-2 text-fg")
                  }
                >
                  {p.name}
                </button>
              ))}
            </div>
            <p className="mt-2 text-xs text-muted">
              {PRESETS.find((p) => p.id === presetId)?.note}
            </p>
          </div>

          <Slider
            label="Semi-major axis a"
            value={a}
            min={0.35}
            max={4}
            step={0.01}
            unit="AU"
            onChange={(v) => {
              setPresetId("custom");
              setA(v);
              resetOrbit(v, e);
            }}
          />
          <Slider
            label="Eccentricity e"
            value={e}
            min={0}
            max={0.9}
            step={0.005}
            onChange={(v) => {
              setPresetId("custom");
              setE(v);
              resetOrbit(a, v);
            }}
          />
          <Slider
            label="Sun mass"
            value={mSun}
            min={0.2}
            max={4}
            step={0.05}
            unit="M☉"
            onChange={(v) => {
              setMSun(v);
              const s = sim.current;
              s.mSun = v;
              s.sawPeri = false;
              s.measuredT = 0;
              s.armed = true;
              s.sectorPhase = 0;
              s.poly1 = [];
              s.poly2 = [];
              s.area1 = 0;
              s.area2 = 0;
            }}
          />
          <Slider
            label="Planet mass"
            value={mPlanet}
            min={0}
            max={1.5}
            step={0.01}
            unit="M☉"
            onChange={(v) => {
              setMPlanet(v);
              const s = sim.current;
              s.mPlanet = v;
              s.sawPeri = false;
              s.measuredT = 0;
              s.armed = true;
              s.sectorPhase = 0;
              s.poly1 = [];
              s.poly2 = [];
              s.area1 = 0;
              s.area2 = 0;
            }}
          />
            <Slider
            label="Time rate"
            value={speed}
            min={0.15}
            max={8}
            step={0.05}
            unit="×"
            onChange={setSpeed}
          />
          <Slider
            label="Equal-time window"
            value={windowYears}
            min={0.05}
            max={Math.max(0.08, periodYears(a, mSun, mPlanet) * 0.45)}
            step={0.01}
            unit="yr"
            onChange={(v) => {
              setWindowYears(v);
              const s = sim.current;
              s.armed = true;
              s.area1 = 0;
              s.area2 = 0;
              s.poly1 = [];
              s.poly2 = [];
              s.sectorPhase = 0;
            }}
          />

          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setPlaying((p) => !p)}
              className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-[var(--radius)] bg-primary text-sm font-medium text-bg"
            >
              {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
              {playing ? "Pause" : "Run"}
            </button>
            <button
              type="button"
              onClick={() => resetOrbit()}
              className="flex min-h-11 items-center justify-center gap-2 rounded-[var(--radius)] border border-border bg-surface-2 px-3 text-sm text-fg"
            >
              <RotateCcw className="size-4" />
              Reset
            </button>
          </div>

          <fieldset className="grid grid-cols-2 gap-2">
            <legend className="mb-2 text-xs font-medium tracking-wide text-muted uppercase">
              Overlays
            </legend>
            {(
              [
                ["foci", "Foci"],
                ["axes", "Axes"],
                ["velocity", "Velocity"],
                ["trail", "Trail"],
                ["ghost", "Circle ghost"],
                ["sectors", "Area wedges"],
              ] as const
            ).map(([key, label]) => (
              <label
                key={key}
                className="flex min-h-11 items-center gap-2 rounded-lg border border-border bg-surface-2 px-2 text-sm"
              >
                <input
                  type="checkbox"
                  checked={overlays[key]}
                  onChange={() =>
                    setOverlays((o) => {
                      const next = { ...o, [key]: !o[key] };
                      if (key === "sectors" && next.sectors) sim.current.armed = true;
                      return next;
                    })
                  }
                />
                {label}
              </label>
            ))}
          </fieldset>

          <div className="rounded-lg border border-border bg-bg p-3 text-sm">
            <div className="mb-2 flex items-center gap-2 text-accent">
              <Ruler className="size-4" />
              <span className="font-medium">Equal areas</span>
            </div>
            <p className="text-xs leading-relaxed text-muted">
              Two wedges of the same duration. Kepler’s second law says their areas match,
              even when the planet is slow at aphelion and fast at perihelion.
            </p>
            <dl className="mt-3 grid grid-cols-3 gap-2 text-center">
              <AreaCell label="Wedge A" value={readout.area1} />
              <AreaCell label="Wedge B" value={readout.area2} />
              <AreaCell label="Theory" value={readout.theoryArea} />
            </dl>
            <p className="mt-3 text-xs text-muted">
              Third law check: T² (M + m) / a³ ={" "}
              <span className="text-fg">
                {format((periodYears(a, mSun, mPlanet) ** 2 * (mSun + mPlanet)) / a ** 3, 4)}
              </span>{" "}
              (should stay 1). A heavier sun or planet shortens the year. Perihelion{" "}
              {format(a * (1 - e), 3)} AU, aphelion {format(a * (1 + e), 3)} AU.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-[var(--radius)] border border-border bg-surface px-3 py-2">
      <p className="text-[11px] tracking-wide text-muted uppercase">{label}</p>
      <p className="font-serif text-lg text-fg">{value}</p>
      {hint ? <p className="text-[11px] text-accent">{hint}</p> : null}
    </div>
  );
}

function AreaCell({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <dt className="text-[11px] text-muted">{label}</dt>
      <dd className="font-serif text-base text-fg">{value > 0 ? format(value, 3) : "—"}</dd>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  unit,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit?: string;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <span className="mb-1 flex items-baseline justify-between text-sm">
        <span>{label}</span>
        <span className="font-serif text-primary">
          {format(value, step < 0.01 ? 3 : 2)}
          {unit ? ` ${unit}` : ""}
        </span>
      </span>
      <input
        className="h-11 w-full"
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(ev) => onChange(Number(ev.target.value))}
      />
    </label>
  );
}

function draw(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  s: {
    a: number;
    e: number;
    overlays: Overlays;
    trail: { x: number; y: number }[];
    poly1: { x: number; y: number }[];
    poly2: { x: number; y: number }[];
  },
  st: { x: number; y: number; vx: number; vy: number },
) {
  const w = canvas.width;
  const h = canvas.height;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const extent = s.a * (1 + s.e) * 1.18;
  const scale = (Math.min(w, h) * 0.42) / Math.max(extent, 0.2);
  const cx = w * 0.5;
  const cy = h * 0.52;

  const X = (x: number) => cx + x * scale;
  const Y = (y: number) => cy - y * scale;

  // stars
  ctx.fillStyle = "#070b14";
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "rgba(232,238,246,0.55)";
  const seed = 17;
  for (let i = 0; i < 70; i++) {
    const px = ((i * 97 + seed * 13) % 1000) / 1000;
    const py = ((i * 53 + seed * 7) % 1000) / 1000;
    const r = (i % 5 === 0 ? 1.6 : 0.8) * (w / 800);
    ctx.beginPath();
    ctx.arc(px * w, py * h, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const b = s.a * Math.sqrt(Math.max(0, 1 - s.e * s.e));
  const c = s.a * s.e;

  if (s.overlays.ghost && s.e > 0.002) {
    ctx.beginPath();
    ctx.strokeStyle = "rgba(139,155,176,0.45)";
    ctx.setLineDash([6, 6]);
    ctx.lineWidth = Math.max(1, w / 900);
    ctx.ellipse(cx, cy, s.a * scale, s.a * scale, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // ellipse: center is at x = -? Wait positions are from focus at 0.
  // geometric center is at x = -c? Point at E=0 is a(1-e) from focus toward +x,
  // apoapsis at -a(1+e). Midpoint of peri and apo:
  // peri x = a(1-e), apo x = -a(1+e), center x = (peri+apo)/2 = (a - a e - a - a e)/2 = -a e = -c
  const centerX = -c;

  if (s.overlays.sectors) {
    paintWedge(ctx, s.poly1, X, Y, "rgba(240,180,41,0.28)");
    paintWedge(ctx, s.poly2, X, Y, "rgba(62,224,197,0.28)");
  }

  ctx.beginPath();
  ctx.strokeStyle = "#3ee0c5";
  ctx.lineWidth = Math.max(1.5, w / 700);
  ctx.ellipse(X(centerX), Y(0), s.a * scale, b * scale, 0, 0, Math.PI * 2);
  ctx.stroke();

  if (s.overlays.axes) {
    ctx.strokeStyle = "rgba(232,238,246,0.35)";
    ctx.lineWidth = Math.max(1, w / 1100);
    ctx.beginPath();
    ctx.moveTo(X(centerX - s.a), Y(0));
    ctx.lineTo(X(centerX + s.a), Y(0));
    ctx.moveTo(X(centerX), Y(-b));
    ctx.lineTo(X(centerX), Y(b));
    ctx.stroke();
  }

  if (s.overlays.trail && s.trail.length > 1) {
    ctx.beginPath();
    ctx.strokeStyle = "rgba(240,180,41,0.75)";
    ctx.lineWidth = Math.max(1.25, w / 900);
    s.trail.forEach((p, i) => {
      if (i === 0) ctx.moveTo(X(p.x), Y(p.y));
      else ctx.lineTo(X(p.x), Y(p.y));
    });
    ctx.stroke();
  }

  // sun at focus (origin) and empty focus at -2c
  const sunR = Math.max(7, w / 90);
  const g = ctx.createRadialGradient(X(0), Y(0), sunR * 0.2, X(0), Y(0), sunR * 2.4);
  g.addColorStop(0, "rgba(240,180,41,0.9)");
  g.addColorStop(1, "rgba(240,180,41,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(X(0), Y(0), sunR * 2.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#f0b429";
  ctx.beginPath();
  ctx.arc(X(0), Y(0), sunR, 0, Math.PI * 2);
  ctx.fill();

  if (s.overlays.foci) {
    ctx.fillStyle = "#e8eef6";
    ctx.beginPath();
    ctx.arc(X(-2 * c), Y(0), Math.max(3, w / 280), 0, Math.PI * 2);
    ctx.fill();
    ctx.font = `${Math.max(12, w / 70)}px Outfit, sans-serif`;
    ctx.fillStyle = "rgba(232,238,246,0.7)";
    ctx.fillText("empty focus", X(-2 * c) + 8, Y(0) - 8);
    ctx.fillText("sun", X(0) + sunR + 4, Y(0) + 4);
  }

  // planet
  ctx.fillStyle = "#e8eef6";
  ctx.beginPath();
  ctx.arc(X(st.x), Y(st.y), Math.max(4.5, w / 160), 0, Math.PI * 2);
  ctx.fill();

  if (s.overlays.velocity) {
    const vScale = scale * 0.18;
    ctx.strokeStyle = "#f0b429";
    ctx.lineWidth = Math.max(1.5, w / 800);
    ctx.beginPath();
    ctx.moveTo(X(st.x), Y(st.y));
    ctx.lineTo(X(st.x) + st.vx * vScale, Y(st.y) - st.vy * vScale);
    ctx.stroke();
  }
}

function paintWedge(
  ctx: CanvasRenderingContext2D,
  pts: { x: number; y: number }[],
  X: (x: number) => number,
  Y: (y: number) => number,
  color: string,
) {
  if (pts.length < 2) return;
  ctx.beginPath();
  ctx.moveTo(X(pts[0].x), Y(pts[0].y));
  for (let i = 1; i < pts.length; i++) ctx.lineTo(X(pts[i].x), Y(pts[i].y));
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
}
